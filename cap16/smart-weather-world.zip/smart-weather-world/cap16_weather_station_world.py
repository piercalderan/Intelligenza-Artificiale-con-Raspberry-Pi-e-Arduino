from flask import Flask, render_template, request, jsonify, send_file
import requests
import os
import io
import hashlib
from gtts import gTTS

app = Flask(__name__)

# === Configura la tua API Key (OpenWeatherMap) ===
BASE_URL = "http://api.openweathermap.org/data/2.5/"
API_KEY = 'openweathermap-api-key'

# =========================
# Utility METEO
# =========================
def get_location():
    try:
        resp = requests.get("https://ipinfo.io/json", timeout=5)
        data = resp.json()
        city = data.get("city", "Roma")  # Default se non disponibile
        return city
    except Exception as e:
        print(f"Errore di geolocalizzazione: {e}")
        return "Roma"

def get_weather(city):
    url = f"{BASE_URL}weather?q={city}&appid={API_KEY}&units=metric&lang=it"
    r = requests.get(url, timeout=10)
    return r.json()

def get_forecast(city):
    url = f"{BASE_URL}forecast?q={city}&appid={API_KEY}&units=metric&lang=it"
    r = requests.get(url, timeout=10)
    return r.json()

def beaufort_scale(speed):
    """Convert wind speed (m/s) to Beaufort scale and description."""
    thresholds = [0.2, 1.5, 3.3, 5.4, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6]
    descriptions = ["Calma", "Bava di vento", "Brezza leggera", "Brezza tesa", "Vento moderato",
                    "Vento fresco", "Vento forte", "Burrasca", "Burrasca forte", "Tempesta",
                    "Fortunale", "Uragano"]
    for i, threshold in enumerate(thresholds):
        if speed <= threshold:
            return i, descriptions[i]
    return 12, "Uragano"

# Filtri Jinja2 per le icone/descrizioni Beaufort
def beaufort_icon(speed):
    index, _ = beaufort_scale(speed)
    return str(index)

def beaufort_description(speed):
    _, description = beaufort_scale(speed)
    return description

app.jinja_env.filters['beaufort_icon'] = beaufort_icon
app.jinja_env.filters['beaufort_description'] = beaufort_description

# =========================
# Wikipedia / Foto
# =========================
WIKI_SUMMARY_URL = "https://{lang}.wikipedia.org/api/rest_v1/page/summary/{title}"
WIKI_IMAGE_SEARCH = "https://{lang}.wikipedia.org/w/api.php"

def wiki_summary_best(title, preferred_lang="it", fallback_lang="en"):
    for lang in [preferred_lang, fallback_lang]:
        try:
            resp = requests.get(
                WIKI_SUMMARY_URL.format(lang=lang, title=title),
                timeout=8,
                headers={"User-Agent": "SmartWeatherStation/1.0"}
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("type") not in ("https://mediawiki.org/wiki/HyperSwitch/errors/not_found", "disambiguation"):
                    return {
                        "lang": lang,
                        "title": data.get("title", title),
                        "extract": data.get("extract", ""),
                        "url": data.get("content_urls", {}).get("desktop", {}).get("page") or data.get("content_urls", {}).get("mobile", {}).get("page"),
                        "thumbnail": (data.get("originalimage", {}) or data.get("thumbnail", {})).get("source")
                    }
        except Exception as e:
            print("Errore wiki_summary_best:", e)
    return {"lang": preferred_lang, "title": title, "extract": "", "url": None, "thumbnail": None}

def wiki_photo_gallery(title, lang="it", limit=6, thumb_size=800):
    try:
        params = {
            "action": "query",
            "format": "json",
            "generator": "search",
            "gsrsearch": title,
            "gsrlimit": limit,
            "prop": "pageimages",
            "piprop": "thumbnail",
            "pithumbsize": thumb_size,
        }
        r = requests.get(WIKI_IMAGE_SEARCH.format(lang=lang), params=params, timeout=10,
                         headers={"User-Agent": "SmartWeatherStation/1.0"})
        data = r.json()
        pages = data.get("query", {}).get("pages", {})
        images = []
        for _, p in pages.items():
            thumb = p.get("thumbnail", {}).get("source")
            if thumb:
                images.append({"title": p.get("title"), "thumbnail": thumb})
        return images
    except Exception as e:
        print("Errore wiki_photo_gallery:", e)
        return []

# =========================
# ROUTES
# =========================
@app.route("/", methods=["GET", "POST"])
def index():
    city = get_location()
    if request.method == "POST":
        city = request.form.get("city") or city

    weather = get_weather(city)
    forecast = get_forecast(city)

    # Precarico descrizione e foto per la pagina
    place_desc = wiki_summary_best(city)
    place_photos = wiki_photo_gallery(city, lang="it", limit=6) or wiki_photo_gallery(city, lang="en", limit=6)

    return render_template("index.html",
                           city=city,
                           weather=weather,
                           forecast=forecast,
                           place_desc=place_desc,
                           place_photos=place_photos)

@app.route("/api/describe")
def api_describe():
    city = request.args.get("city") or get_location()
    desc = wiki_summary_best(city)
    if not desc.get("extract"):
        alt = f"{city} (città)"
        d2 = wiki_summary_best(alt)
        if d2.get("extract"):
            desc = d2
    return jsonify({
        "city": city,
        "lang": desc.get("lang"),
        "title": desc.get("title"),
        "summary": desc.get("extract"),
        "url": desc.get("url"),
        "thumbnail": desc.get("thumbnail")
    })

@app.route("/api/photos")
def api_photos():
    city = request.args.get("city") or get_location()
    lang = request.args.get("lang", "it")
    limit = int(request.args.get("limit", "6"))
    photos = wiki_photo_gallery(city, lang=lang, limit=limit)
    if not photos and lang != "en":
        photos = wiki_photo_gallery(city, lang="en", limit=limit)
    return jsonify({"city": city, "photos": photos})

def tts_bytes(text, lang="it"):
    h = hashlib.md5((lang + "|" + text).encode("utf-8")).hexdigest()
    cache_path = os.path.join("/tmp", f"tts_{h}.mp3")
    if not os.path.exists(cache_path):
        tts = gTTS(text=text, lang=lang)
        tts.save(cache_path)
    with open(cache_path, "rb") as f:
        return f.read()

@app.route("/tts")
def tts():
    text = request.args.get("text", "").strip()
    if not text:
        return "Parametro 'text' mancante.", 400
    lang = request.args.get("lang", "it")
    audio = tts_bytes(text, lang=lang)
    return send_file(io.BytesIO(audio), mimetype="audio/mpeg", as_attachment=False, download_name="tts.mp3")

@app.route("/tts/describe")
def tts_describe():
    city = request.args.get("city") or get_location()
    lang = request.args.get("lang", "it")
    desc = wiki_summary_best(city, preferred_lang=lang)
    summary = desc.get("extract") or f"{city}: descrizione non disponibile."
    audio = tts_bytes(summary, lang=lang)
    return send_file(io.BytesIO(audio), mimetype="audio/mpeg", as_attachment=False, download_name=f"{city}_descrizione.mp3")

if __name__ == "__main__":
    # Avvia: python cap16_weather_station_world.py  (poi apri http://127.0.0.1:5000)
    app.run(debug=True, host="0.0.0.0", port=5000)
