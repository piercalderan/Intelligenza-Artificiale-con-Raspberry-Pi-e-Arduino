from flask import Flask, render_template, request, jsonify, send_file, abort
import requests
import io
import hashlib
from gtts import gTTS
import os, json, csv, threading, time, queue, sqlite3
from datetime import datetime, timedelta
from dotenv import load_dotenv
import logging as log

log.basicConfig(level=log.INFO, format="%(asctime)s %(levelname)s %(message)s")

app = Flask(__name__)

# === Configura la tua API Key (OpenWeatherMap) ===
BASE_URL = "http://api.openweathermap.org/data/2.5/"
API_KEY = 'openweathermap-api-key'


# ---------------- Config ----------------
load_dotenv()
SERIAL_PORT = os.getenv("SERIAL_PORT", "/dev/ttyACM0")
BAUD = int(os.getenv("BAUD", "115200"))
SERIAL_BAUD = BAUD
HISTORY_MIN = int(os.getenv("HISTORY_MIN", "60"))  # minuti di history in RAM

DATA_DIR = "data"; os.makedirs(DATA_DIR, exist_ok=True)
CSV_PATH = os.path.join(DATA_DIR, "weather.csv")
DB_PATH  = os.path.join(DATA_DIR, "weather.db")
USE_SQLITE = os.getenv("USE_SQLITE", "0") == "1"
TTS_PROVIDER = os.getenv("TTS_PROVIDER", "openai")  # default: openai

# --------------- Serial (Cap 15 style) ---------------
try:
    import serial
    from serial import SerialException
    HAVE_SERIAL = True
except Exception:
    HAVE_SERIAL = False
    log.warning("pyserial non installato: lettura Arduino disattivata.")

serial_in_q: "queue.Queue[str]" = queue.Queue()
serial_out_q: "queue.Queue[str]" = queue.Queue()

latest = {"temp": None, "hum": None, "ts": None}   # ultimo valore per /api/latest
ring = []  # [(ts_iso, temp, hum)]
ring_lock = threading.Lock()

def csv_append(ts_iso, temp, hum):
    new_file = not os.path.exists(CSV_PATH)
    with open(CSV_PATH, "a", newline="") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(["timestamp_iso", "temp", "hum"])
        w.writerow([ts_iso, temp, hum])

def prune_ring():
    cutoff = datetime.utcnow() - timedelta(minutes=HISTORY_MIN + 10)
    with ring_lock:
        keep = []
        for ts_iso, t, h in ring:
            try:
                ts = datetime.fromisoformat(ts_iso.replace("Z",""))
            except Exception:
                continue
            if ts >= cutoff:
                keep.append((ts_iso, t, h))
        ring[:] = keep

def serial_reader():
    if not HAVE_SERIAL:
        return
    while True:
        try:
            with serial.Serial(SERIAL_PORT, SERIAL_BAUD, timeout=1, exclusive=True) as ser:
                log.info(f"[SERIAL] Aperto {SERIAL_PORT} @ {SERIAL_BAUD}")

                def sender():
                    while True:
                        try:
                            cmd = serial_out_q.get(timeout=0.2)
                        except queue.Empty:
                            continue
                        if cmd:
                            try:
                                ser.write((cmd.strip() + "\n").encode("utf-8"))
                            except Exception as e:
                                log.warning(f"[SERIAL] errore invio: {e}")
                threading.Thread(target=sender, daemon=True).start()

                while True:
                    line = ser.readline()
                    if not line:
                        continue
                    raw = line.decode("utf-8", errors="ignore").strip()
                    serial_in_q.put(raw)

        except Exception as e:
            log.warning(f"[SERIAL] errore apertura/lettura: {e}; retry fra 2s")
            time.sleep(2)

def serial_parser():
    while True:
        raw = serial_in_q.get()
        try:
            data = json.loads(raw)  # atteso: {"temp":..,"hum":..,"ts":..}
            t = float(data.get("temp"))
            h = float(data.get("hum"))
            print("temp:",t,"hum",h)
            ts_iso = data.get("ts") or datetime.utcnow().isoformat(timespec="seconds")
            latest.update({"temp": t, "hum": h, "ts": ts_iso})
            with ring_lock:
                ring.append((ts_iso, t, h))
            csv_append(ts_iso, t, h)
            prune_ring()
        except Exception:
            if "t" in raw and "h" in raw:
                try:
                    parts = raw.replace(":", " ").replace(",", " ").split()
                    nums = [p for p in parts if any(c.isdigit() for c in p)]
                    vals = [float(s.replace("t=","").replace("h=","")) for s in nums[:2]]
                    t, h = vals[0], vals[1]
                    ts_iso = datetime.utcnow().isoformat(timespec="seconds")
                    latest.update({"temp": t, "hum": h, "ts": ts_iso})
                    with ring_lock:
                        ring.append((ts_iso, t, h))
                    csv_append(ts_iso, t, h)
                    prune_ring()
                except Exception:
                    pass

threading.Thread(target=serial_reader, daemon=True).start()
threading.Thread(target=serial_parser, daemon=True).start()

# --------------- TTS --------------------
def tts_openai(text, out_path):
    from openai import OpenAI
    client = OpenAI()
    with client.audio.speech.with_streaming_response.create(
        model="gpt-4o-mini-tts",
        voice="alloy",
        input=text,
        response_format="wav"
    ) as response:
        response.stream_to_file(out_path)
    return out_path

def tts_gtts(text, out_path):
    from gtts import gTTS
    tts = gTTS(text=text, lang="it")
    tts.save(out_path)
    return out_path

def speak(text):
    out = os.path.join(DATA_DIR, "voice.wav")
    if TTS_PROVIDER == "gtts":
        return tts_gtts(text, out)
    return tts_openai(text, out)

# --------------- Flask ------------------

@app.get("/api/latest")
def api_latest():
    return jsonify(latest)

@app.get("/api/history")
def api_history():
    N = int(request.args.get("n", "200"))
    with ring_lock:
        rows = [{"timestamp_iso": ts, "temp": t, "hum": h} for (ts,t,h) in ring[-N:]]
    return jsonify(rows)

@app.post("/api/tts")
def api_tts():
    text = request.json.get("text","")
    if not text.strip():
        abort(400, "missing text")
    path = speak(text)
    return send_file(path, mimetype="audio/wav", as_attachment=False)

@app.post("/api/arduino/led")
def api_led():
    action = request.json.get("action")
    if action == "on":
        serial_out_q.put("LED_ON")
    elif action == "off":
        serial_out_q.put("LED_OFF")
    return jsonify({"ok": True})


# =========================
# Utility METEO
# =========================
def get_location():
    try:
        resp = requests.get("https://ipinfo.io/json", timeout=5)
        data = resp.json()
        city = data.get("city", "Roma")  # Default se non disponibile
        return city
    except Exception as e:
        print(f"Errore di geolocalizzazione: {e}")
        return "Roma"

def get_weather(city):
    url = f"{BASE_URL}weather?q={city}&appid={API_KEY}&units=metric&lang=it"
    r = requests.get(url, timeout=10)
    return r.json()

def get_forecast(city):
    url = f"{BASE_URL}forecast?q={city}&appid={API_KEY}&units=metric&lang=it"
    r = requests.get(url, timeout=10)
    return r.json()

def beaufort_scale(speed):
    """Convert wind speed (m/s) to Beaufort scale and description."""
    thresholds = [0.2, 1.5, 3.3, 5.4, 7.9, 10.7, 13.8, 17.1, 20.7, 24.4, 28.4, 32.6]
    descriptions = ["Calma", "Bava di vento", "Brezza leggera", "Brezza tesa", "Vento moderato",
                    "Vento fresco", "Vento forte", "Burrasca", "Burrasca forte", "Tempesta",
                    "Fortunale", "Uragano"]
    for i, threshold in enumerate(thresholds):
        if speed <= threshold:
            return i, descriptions[i]
    return 12, "Uragano"

# Filtri Jinja2 per le icone/descrizioni Beaufort
def beaufort_icon(speed):
    index, _ = beaufort_scale(speed)
    return str(index)

def beaufort_description(speed):
    _, description = beaufort_scale(speed)
    return description

app.jinja_env.filters['beaufort_icon'] = beaufort_icon
app.jinja_env.filters['beaufort_description'] = beaufort_description

# =========================
# Wikipedia / Foto
# =========================
WIKI_SUMMARY_URL = "https://{lang}.wikipedia.org/api/rest_v1/page/summary/{title}"
WIKI_IMAGE_SEARCH = "https://{lang}.wikipedia.org/w/api.php"

def wiki_summary_best(title, preferred_lang="it", fallback_lang="en"):
    for lang in [preferred_lang, fallback_lang]:
        try:
            resp = requests.get(
                WIKI_SUMMARY_URL.format(lang=lang, title=title),
                timeout=8,
                headers={"User-Agent": "SmartWeatherStation/1.0"}
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("type") not in ("https://mediawiki.org/wiki/HyperSwitch/errors/not_found", "disambiguation"):
                    return {
                        "lang": lang,
                        "title": data.get("title", title),
                        "extract": data.get("extract", ""),
                        "url": data.get("content_urls", {}).get("desktop", {}).get("page") or data.get("content_urls", {}).get("mobile", {}).get("page"),
                        "thumbnail": (data.get("originalimage", {}) or data.get("thumbnail", {})).get("source")
                    }
        except Exception as e:
            print("Errore wiki_summary_best:", e)
    return {"lang": preferred_lang, "title": title, "extract": "", "url": None, "thumbnail": None}

def wiki_photo_gallery(title, lang="it", limit=6, thumb_size=800):
    try:
        params = {
            "action": "query",
            "format": "json",
            "generator": "search",
            "gsrsearch": title,
            "gsrlimit": limit,
            "prop": "pageimages",
            "piprop": "thumbnail",
            "pithumbsize": thumb_size,
        }
        r = requests.get(WIKI_IMAGE_SEARCH.format(lang=lang), params=params, timeout=10,
                         headers={"User-Agent": "SmartWeatherStation/1.0"})
        data = r.json()
        pages = data.get("query", {}).get("pages", {})
        images = []
        for _, p in pages.items():
            thumb = p.get("thumbnail", {}).get("source")
            if thumb:
                images.append({"title": p.get("title"), "thumbnail": thumb})
        return images
    except Exception as e:
        print("Errore wiki_photo_gallery:", e)
        return []

# =========================
# ROUTES
# =========================
@app.route("/", methods=["GET", "POST"])
def index():
    city = get_location()
    if request.method == "POST":
        city = request.form.get("city") or city

    weather = get_weather(city)
    forecast = get_forecast(city)

    # Precarico descrizione e foto per la pagina
    place_desc = wiki_summary_best(city)
    place_photos = wiki_photo_gallery(city, lang="it", limit=6) or wiki_photo_gallery(city, lang="en", limit=6)

    return render_template("index_ws_simple.html",
                           city=city,
                           weather=weather,
                           forecast=forecast,
                           place_desc=place_desc,
                           place_photos=place_photos)

@app.route("/api/describe")
def api_describe():
    city = request.args.get("city") or get_location()
    desc = wiki_summary_best(city)
    if not desc.get("extract"):
        alt = f"{city} (città)"
        d2 = wiki_summary_best(alt)
        if d2.get("extract"):
            desc = d2
    return jsonify({
        "city": city,
        "lang": desc.get("lang"),
        "title": desc.get("title"),
        "summary": desc.get("extract"),
        "url": desc.get("url"),
        "thumbnail": desc.get("thumbnail")
    })

@app.route("/api/photos")
def api_photos():
    city = request.args.get("city") or get_location()
    lang = request.args.get("lang", "it")
    limit = int(request.args.get("limit", "6"))
    photos = wiki_photo_gallery(city, lang=lang, limit=limit)
    if not photos and lang != "en":
        photos = wiki_photo_gallery(city, lang="en", limit=limit)
    return jsonify({"city": city, "photos": photos})

def tts_bytes(text, lang="it"):
    h = hashlib.md5((lang + "|" + text).encode("utf-8")).hexdigest()
    cache_path = os.path.join("/tmp", f"tts_{h}.mp3")
    if not os.path.exists(cache_path):
        tts = gTTS(text=text, lang=lang)
        tts.save(cache_path)
    with open(cache_path, "rb") as f:
        return f.read()

@app.route("/tts")
def tts():
    text = request.args.get("text", "").strip()
    if not text:
        return "Parametro 'text' mancante.", 400
    lang = request.args.get("lang", "it")
    audio = tts_bytes(text, lang=lang)
    return send_file(io.BytesIO(audio), mimetype="audio/mpeg", as_attachment=False, download_name="tts.mp3")

@app.route("/tts/describe")
def tts_describe():
    city = request.args.get("city") or get_location()
    lang = request.args.get("lang", "it")
    desc = wiki_summary_best(city, preferred_lang=lang)
    summary = desc.get("extract") or f"{city}: descrizione non disponibile."
    audio = tts_bytes(summary, lang=lang)
    return send_file(io.BytesIO(audio), mimetype="audio/mpeg", as_attachment=False, download_name=f"{city}_descrizione.mp3")

if __name__ == "__main__":
    # Avvia: python cap16_weather_station_world_simple.py  (poi apri http://127.0.0.1:5000)
    app.run(debug=False, host="0.0.0.0", port=5000)
